self.addEventListener('install', function(event) {
  console.log('Service Worker installing.');
});
